﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ofir_Shtainfeld
{
    public enum AlertTypes
    {
        CameraCover,
        CameraDisconnected,
        EnterROI,
        ExitROI,
        MotionDitection,
        ROUMovement,
    }

}
