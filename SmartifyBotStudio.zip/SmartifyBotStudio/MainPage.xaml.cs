﻿using MahApps.Metro.Controls;
using Microsoft.Win32;
using SmartifyBotStudio.Helpers.DragDropListView;
using SmartifyBotStudio.Models;
using SmartifyBotStudio.RobotDesigner.TaskModel;
using SmartifyBotStudio.RobotDesigner.TaskModel.File;
using SmartifyBotStudio.RobotDesigner.TaskView;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace SmartifyBotStudio
{
    /// <summary>
    /// Interaction logic for MainPage.xaml
    /// </summary>
    public partial class MainPage : UserControl
    {
        RobotDesignerProjectModel projectModel;

        ListViewDragDropManager<RobotActionBase> dragMgr;
        ListViewDragDropManager<RobotActionBase> dragMgr2;

        ObservableCollection<RobotActionBase> actionCollection;

        #region Constructor
        public MainPage()
        {
            InitializeComponent();
            
            this.Loaded += MainPage_Loaded;


            projectModel = new RobotDesignerProjectModel()
            {
                Actions = actionCollection,
                Description = "This is test p description",
                Owner = Environment.UserName,
                ProjectName = "Test Projet",


            };


        }

        private void MainPage_Loaded(object sender, RoutedEventArgs e)
        {

            docManager.ChangeColorScheme(DevComponents.WpfDock.eDockVisualStyle.Office2010Black, System.Windows.Media.Color.FromRgb(0,0,0));
            
            

            actionCollection = new ObservableCollection<RobotActionBase>();
            actionCollection.CollectionChanged += ActionCollection_CollectionChanged;

            this.listView.ItemsSource = actionCollection;
            listView.SelectionChanged += (o, oo) => 
            {

                propertyGrid.SelectedObject = listView.SelectedItem as RobotActionBase;
            };

            this.lstFileActions.ItemsSource = RobotActionBase.CreateFileTasks();

            //this.listView2.ItemsSource = new ObservableCollection<IRobotActionBase>()
            //{
            //     new FileCopy(){ Icon = MaterialDesignThemes.Wpf.PackIconKind.AccessPoint, Name = "A", Description =  "AAA", ID  = "AAA", Finished =  false, IsExisting =  false },
            //     new FileCopy(){ Icon = MaterialDesignThemes.Wpf.PackIconKind.XboxControllerOff, Name = "B", Description =  "BBB", ID  = "AAA", Finished =  false, IsExisting =  false },
            //     new FileCopy(){ Icon = MaterialDesignThemes.Wpf.PackIconKind.XingBox, Name = "C", Description =  "AAA", ID  = "BBB", Finished =  false, IsExisting =  false },
            //     new FileCopy(){ Icon = MaterialDesignThemes.Wpf.PackIconKind.Yelp, Name = "D", Description =  "AAA", ID  = "CCC", Finished =  false, IsExisting =  false },


            //};
            
            this.dragMgr = new ListViewDragDropManager<RobotActionBase>(this.listView);
            this.dragMgr2 = new ListViewDragDropManager<RobotActionBase>(this.lstFileActions);


            this.listView.DragEnter += OnListViewDragEnter;
            this.listView.Drop += OnListViewDrop;

            this.lstFileActions.DragEnter += OnListViewDragEnter;
            this.lstFileActions.Drop += OnListViewDrop;

        }

        private void ActionCollection_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            ICollectionView view = CollectionViewSource.GetDefaultView(listView.ItemsSource);
            view.Refresh();
        }

        #endregion

        #region OnListViewDragEnter

        // Handles the DragEnter event for both ListViews.
        void OnListViewDragEnter(object sender, DragEventArgs e)
        {
            e.Effects = DragDropEffects.Move;
        }

        #endregion // OnListViewDragEnter

        #region OnListViewDrop

        // Handles the Drop event for both ListViews.
        void OnListViewDrop(object sender, DragEventArgs e)
        {
            if (e.Effects == DragDropEffects.None)
                return;

            RobotActionBase task = e.Data.GetData(typeof(RobotActionBase)) as RobotActionBase;
            if (sender == this.listView)
            {
                if (this.dragMgr.IsDragInProgress)
                    return;

                // An item was dragged from the bottom ListView into the top ListView
                // so remove that item from the bottom ListView.
                //(this.listView2.ItemsSource as ObservableCollection<Task>).Remove(task);
            }
            else
            {
                if (this.dragMgr2.IsDragInProgress)
                    return;

                // An item was dragged from the top ListView into the bottom ListView
                // so remove that item from the top ListView.
                (this.listView.ItemsSource as ObservableCollection<RobotActionBase>).Remove(task);
            }
        }

        #endregion // OnListViewDrop

        private void mnuExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }




        private void listView_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var s = listView.SelectedItem as RobotActionBase;
            //if (s != null)
            //    MessageBox.Show(s.Description);
            var m = new MetroWindow()
            {
                 //copyFilesAction,
                SizeToContent = SizeToContent.WidthAndHeight,
                WindowStyle = WindowStyle.SingleBorderWindow,
                WindowState = WindowState.Normal,
                //Title = "Copy File",
                ShowMaxRestoreButton = false,
                ShowMinButton = false,
                ResizeMode = ResizeMode.NoResize,
                WindowStartupLocation = WindowStartupLocation.CenterScreen
            };

            m.Content = new TaskViewFrameUC()
            {
                TaskType = s.ActionType,
                TaskData = listView.SelectedItem
            };

            //switch (s.ActionType)
            //{
            //    case RobotDesigner.Enums.RobotActionsEnum.CopyFile:
            //        m.Content = new TaskViewFrameUC()
            //        {
            //            TaskType = RobotDesigner.Enums.RobotActionsEnum.CopyFile,
            //            TaskData = listView.SelectedItem
            //        };

            //        break;
            //    case RobotDesigner.Enums.RobotActionsEnum.DeleteFile:
            //        m.Content = new TaskViewFrameUC()
            //        {
            //            TaskType = RobotDesigner.Enums.RobotActionsEnum.DeleteFile,
            //            TaskData = listView.SelectedItem
            //        };

            //        break;
            //}

            if (m.ShowDialog() == true)
            {
                //if (copyFilesAction.CopyFilesData != null)
                //{
                //    ICollectionView view = CollectionViewSource.GetDefaultView(listView.ItemsSource);
                //    view.Refresh();
                //}
            }
        }

        private void mnuSave_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog opnFileDialog = new SaveFileDialog()
            {
                FileName = "Project1",
                
                AddExtension = true,
                //CheckFileExists = true,
                CheckPathExists = true,
                DefaultExt = "bot",
                Title = "Save Robot Designer File",
                Filter = "Smartify Bot files (*.bot)|*.bot|All files (*.*)|*.*"

        };

            if (opnFileDialog.ShowDialog() ==  true)
            {
                SaveProject(opnFileDialog.FileName);
            }

            
        }


        /// <summary>
        /// Save graphics to XML file.
        /// Throws: DrawingCanvasException.
        /// </summary>
        public void SaveProject(string fileName)
        {



            //var stringwriter = new System.IO.StringWriter();
            //var serializer = new XmlSerializer(typeof(RobotDesignerProjectModel));
            projectModel.Actions = actionCollection;



            //serializer.Serialize(stringwriter, projectModel);
            //var str =  stringwriter.ToString();
            //File.WriteAllText(fileName, str);


            FileStream fs = new FileStream(fileName, FileMode.Create);

            // Construct a BinaryFormatter and use it to serialize the data to the stream.
            BinaryFormatter formatter = new BinaryFormatter();
            try
            {
                formatter.Serialize(fs, projectModel);
            }
            catch (SerializationException e)
            {
                Console.WriteLine("Failed to serialize. Reason: " + e.Message);
                throw;
            }
            finally
            {
                fs.Close();
            }


            //return;

            //====================================================

            //XmlSerializer s = new XmlSerializer(typeof(SerializationHelper));

            //// Writing the XML file to disk requires a TextWriter.
            //TextWriter writer = new StreamWriter(fileName);


            //SerializationHelper helper = new SerializationHelper(actionCollection);

            //RobotActionBase[] actions = new RobotActionBase[listView.Items.Count];
            //int i = 0;
            //foreach (var item in listView.Items)
            //{
            //    actions[i] = (RobotActionBase)item;

            //    i++;
            //}


            //helper.RobotActions = actions;

            // Creates an int and a string and assigns to ExtraInfo.
            //group.ExtraInfo = new Object[3] { 43, "Extra", manager };

            // Serializes the object, and closes the StreamWriter.
            //s.Serialize(writer, helper);
            //writer.Close();
        }


        void OpenProject(string fileName)
        {

            FileStream fs = new FileStream(fileName, FileMode.Open);
            try
            {
                BinaryFormatter formatter = new BinaryFormatter();

                // Deserialize the hashtable from the file and 
                // assign the reference to the local variable.
                var p = (RobotDesignerProjectModel)formatter.Deserialize(fs);
            }
            catch (SerializationException e)
            {
                Console.WriteLine("Failed to deserialize. Reason: " + e.Message);
                throw;
            }
            finally
            {
                fs.Close();
            }




            //FileStream fs = new FileStream(fileName, FileMode.Open);
            //XmlSerializer x = new XmlSerializer(typeof(SerializationHelper));
            //SerializationHelper g = (SerializationHelper)x.Deserialize(fs);

            //actionCollection.Clear();

            //foreach (var e in g.RobotActions)
            //{
            //    actionCollection.Add(e);
            //}
        }

        

        private void mnuOpen_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog()
            {
               
                CheckFileExists = true,
                CheckPathExists = true,
                DefaultExt = "bot",
                Title = "Open Robot Designer File",
                Filter = "Smartify Bot files (*.bot)|*.bot|All files (*.*)|*.*"
            };


            if (openFileDialog.ShowDialog() == true)
            {
                OpenProject(openFileDialog.FileName);
            }


        }

        private async void btnExecute_Click(object sender, RoutedEventArgs e)
        {
            this.Cursor = Cursors.Wait;

            this.IsEnabled = false;

            int index = 0;
            foreach (var item in actionCollection.Where(v => v.IsActive))
            {
                await PutTaskDelay();

                item.RobotDesignerProject = projectModel;

                listView.SelectedIndex = index;

                switch (item.ActionType)
                {
                    case RobotDesigner.Enums.RobotActionsEnum.CopyFile:
                        if ((item as CopyFiles).Execute() > 0)
                        {
                            index++;
                        }
                        break;
                    case RobotDesigner.Enums.RobotActionsEnum.DeleteFile:
                        if ((item as DeleteFiles).Execute() > 0)
                        {
                            index++;
                        }
                        break;
                    case RobotDesigner.Enums.RobotActionsEnum.MoveFiles:
                        if ((item as MoveFiles).Execute() > 0)
                        {
                            index++;
                        }
                        break;
                }


            }

            this.Cursor = Cursors.Arrow;
            this.IsEnabled = true;
        }


        async Task PutTaskDelay()
        {
            await Task.Delay(1000);
        }

    
    }
}
