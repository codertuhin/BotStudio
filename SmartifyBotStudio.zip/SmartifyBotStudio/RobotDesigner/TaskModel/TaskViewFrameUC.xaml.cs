﻿using MahApps.Metro.Controls;
using SmartifyBotStudio.RobotDesigner.Enums;
using SmartifyBotStudio.RobotDesigner.TaskView.File;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SmartifyBotStudio.RobotDesigner.TaskModel
{
    /// <summary>
    /// Interaction logic for TaskViewFrameUC.xaml
    /// </summary>
    public partial class TaskViewFrameUC : UserControl
    {

        public Object TaskData { get; set; }
        public RobotDesigner.Enums.RobotActionsEnum TaskType { get; set; }

        public TaskViewFrameUC()
        {
            InitializeComponent();

            Loaded += TaskViewFrameUC_Loaded;
        }

        private void TaskViewFrameUC_Loaded(object sender, RoutedEventArgs e)
        {
            LoadTaskUI(TaskType);

        }

        void LoadTaskUI(RobotActionsEnum taskType)
        {
            panelMain.Children.Clear();
            var window = this.Parent as MetroWindow;

            switch (taskType)
            {
                case RobotActionsEnum.CopyFile:

                    panelMain.Children.Add(new CopyFiles() { CopyFilesData = TaskData != null ? TaskData as RobotDesigner.TaskModel.File.CopyFiles : null });
                    break;
                case RobotActionsEnum.DeleteFile:
                    panelMain.Children.Add(new DeleteFiles() { DeleteFileData = TaskData != null ? TaskData as RobotDesigner.TaskModel.File.DeleteFiles : null });
                    break;

                case RobotActionsEnum.MoveFiles:
                    panelMain.Children.Add(new MoveFiles() { MoveFilesData = TaskData != null ? TaskData as RobotDesigner.TaskModel.File.MoveFiles : null });
                    break;
                case RobotActionsEnum.GetFilePathPart:

                    panelMain.Children.Add(new GetFilePathPart());
                    break;
                case RobotActionsEnum.GetFilesinFolder:
                    panelMain.Children.Add(new GetFilesinFolder());
                    break;

                case RobotActionsEnum.GetTemporaryFile:
                    panelMain.Children.Add(new GetTemporaryFile());
                    break;
                case RobotActionsEnum.ReadFromCSVFile:
                    panelMain.Children.Add(new ReadFromCSVFile());
                    break;

                case RobotActionsEnum.ReadTextFromFile:
                    panelMain.Children.Add(new ReadTextfromFile());
                    break;


                case RobotActionsEnum.RenameFiles:
                    panelMain.Children.Add(new RenameFiles());
                    break;

                case RobotActionsEnum.WriteTextToFile:
                    panelMain.Children.Add(new WriteTexttoFile());
                    break;
                case RobotActionsEnum.WriteToCSVFile:
                    panelMain.Children.Add(new WriteToCSVFile());
                    break;

            }

            window.Title = taskType.ToString();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            panelMain.Children.Clear();
            var window = this.Parent as MetroWindow;

            switch ((sender as MenuItem).Tag.ToString())
            {
                case "CopyFile":

                    LoadTaskUI(RobotActionsEnum.CopyFile);
                    break;
                case "DeleteFile":
                    LoadTaskUI(RobotActionsEnum.DeleteFile);
                    break;

                case "MoveFiles":
                    LoadTaskUI(RobotActionsEnum.MoveFiles);
                    break;
                case "GetFilePathPart":

                    LoadTaskUI(RobotActionsEnum.GetFilePathPart);
                    break;
                case "GetFilesInFolder":
                    LoadTaskUI(RobotActionsEnum.GetFilesinFolder);
                    break;

                case "GetTemporaryFiles":
                    LoadTaskUI(RobotActionsEnum.GetTemporaryFile);
                    break;
                case "ReadfromCSVFile":
                    LoadTaskUI(RobotActionsEnum.ReadFromCSVFile);
                    break;

                case "ReadTextfromFile":
                    LoadTaskUI(RobotActionsEnum.ReadTextFromFile);
                    break;


                case "RenameFiles":
                    LoadTaskUI(RobotActionsEnum.RenameFiles);
                    break;

                case "WriteTexttoFile":
                    LoadTaskUI(RobotActionsEnum.WriteTextToFile);
                    break;
                case "WritetoCSVFile":
                    LoadTaskUI(RobotActionsEnum.WriteToCSVFile);
                    break;

            }

            window.Title = (sender as MenuItem).Tag.ToString();
        }
    }
}
