﻿using SmartifyBotStudio.Models;
using SmartifyBotStudio.RobotDesigner.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartifyBotStudio.RobotDesigner.TaskModel.File
{
    public class GetTemporaryFiles : RobotActionBase, ITask
    {
        public int Execute()
        {
            throw new NotImplementedException();
        }
    }
}
