﻿using SmartifyBotStudio.Helpers.Misc;
using SmartifyBotStudio.Models;
using SmartifyBotStudio.RobotDesigner.Interfaces;
using SmartifyBotStudio.RobotDesigner.Variable;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartifyBotStudio.RobotDesigner.TaskModel.File
{
   public class WriteToCSVFile : RobotActionBase,ITask
    {
        public DataTableVariable VariableToWrite { get; set; }
        public string FilePath { get; set; }
        public Encoding Encoding { get; set; }

        public int Execute()
        {
            try
            {
                CSVWriter.WriteCSV(VariableToWrite.Value, FilePath, Encoding);

                return 1;
            }
            catch (Exception)
            {

                return 1;
            }
        }
    }
}
