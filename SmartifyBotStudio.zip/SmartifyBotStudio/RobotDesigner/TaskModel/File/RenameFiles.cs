﻿using SmartifyBotStudio.Models;
using SmartifyBotStudio.RobotDesigner.Interfaces;
using SmartifyBotStudio.RobotDesigner.Variable;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartifyBotStudio.RobotDesigner.TaskModel.File
{
   public class RenameFiles : RobotActionBase, ITask
    {
        public SelectedFileInfo FilesToRename { get; set; }
      
        public string RenameScheme { get; set; }
        public string NewFileName { get; set; }
        public string KeepExtension { get; set; }
        public bool IfFileExists { get; set; }

        public string Var_StoreRenamedFilesInto { get; set; }

        public int Execute()
        {
            try
            {
                List<string> values = new List<string>();

                //foreach (var file in FilesToRename)
                //{
                //    //System.IO.File.Copy(file.FilePath, Path.Combine(Destination, file.FileName), OverWriteIfFilesExixts);

                //    values.Add(file.FilePath);
                //}

                Variables.Add(new ListVariable()
                {
                    RobotAction = this,
                    Value = values,
                    VariableName = Var_StoreRenamedFilesInto
                });

                return 1;
        }
            catch (Exception ex)
            {
                return 0;
            }
}
    }
}
