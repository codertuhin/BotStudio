﻿using MahApps.Metro.Controls;
using SmartifyBotStudio.RobotDesigner.TaskModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SmartifyBotStudio.RobotDesigner.TaskView.File
{
    /// <summary>
    /// Interaction logic for RenameFiles.xaml
    /// </summary>
    public partial class RenameFiles : UserControl
    {
        public RobotDesigner.TaskModel.File.RenameFiles RenameFile { get; set; }
        public RenameFiles()
        {
            InitializeComponent();
            Loaded += RenameFiles_Loaded;
        }

        private void RenameFiles_Loaded(object sender, RoutedEventArgs e)
        {
            if (RenameFile != null)
            {
               // file_text.Text = RenameFile.Destination;
                this_checkbox.IsChecked = RenameFile.IsActive;

                ifExists_dropdown.SelectedIndex = RenameFile.IfFileExists ? 1 : 0;

                if (RenameFile.FilesToRename != null)
                    file_text.Text = RenameFile.FilesToRename.ToString();

                    //foreach (var item in RenameFile.FilesToCopy)
                    //{
                    //    file_text.Text.Insert(new SelectedFileInfo() { Tag = item.FilePath, Content = item.FileName });
                    //}



            }
        }

        private void btnOpenFiles_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog()
            {
                Multiselect = true
            };

            if (openFileDialog.ShowDialog() == true)
            {
                file_text.Text = openFileDialog.FileName;
                //foreach (var item in openFileDialog.FileNames)
                //{

                //    // txtFilesToCopy.Items.Add(new ListBoxItem() { Tag = item, Content = new FileInfo(item).Name });
                //}

            }
        }

        //private void btnOpenFolder_Click(object sender, RoutedEventArgs e)
        //{
        //    FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog()
        //    {
        //        ShowNewFolderButton = true,
        //    };

        //    if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
        //    {
        //        txtDestinationFolder.Text = folderBrowserDialog.SelectedPath;
        //    }
        //}

        private void more_button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ok_button_Click(object sender, RoutedEventArgs e)
        {

            //CopyFilesData.Destination = txtDestinationFolder.Text;
            //List<SelectedFileInfo> files = new List<SelectedFileInfo>();

            //foreach (ListBoxItem item in txtFilesToCopy.Items)
            //{

            //    files.Add(new SelectedFileInfo() { FilePath = item.Tag.ToString(), FileName = item.Content.ToString() });

            //    CopyFilesData.Description = "Files(" + txtFilesToCopy.Items.Count + ") Des:" + txtDestinationFolder.Text;
            //}

            //CopyFilesData.FilesToCopy = files;
            //CopyFilesData.IsActive = (bool)this_checkbox.IsChecked;
            //CopyFilesData.OverWriteIfFilesExixts = Convert.ToBoolean(if_dropdown.SelectedIndex);
            //CopyFilesData.Var_StoreCopiedFiles = store_text.Text;

            ((((this.Parent as StackPanel).Parent as Grid).Parent as TaskViewFrameUC).Parent as MetroWindow).DialogResult = false;

        }

        private void btn_cancel_Click(object sender, RoutedEventArgs e)
        {
            ((((this.Parent as StackPanel).Parent as Grid).Parent as TaskViewFrameUC).Parent as MetroWindow).DialogResult = false;

        }


        //private void format_dropdown_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    //var aa = format_dropdown.SelectedValue as ComboBox;
        //    //if (one.IsSelected == true)
        //    //{
        //    //    example_text.Text = "Cleared";
        //    //}

        //}

    }
}
