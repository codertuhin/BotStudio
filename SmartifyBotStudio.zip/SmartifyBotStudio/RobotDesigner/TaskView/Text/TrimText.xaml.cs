﻿using System;
using System.Linq;
using System.Windows.Controls;

namespace SmartifyBotStudio.RobotDesigner.TaskView.TextActions
{
    /// <summary>
    /// Interaction logic for TrimText.xaml
    /// </summary>
    public partial class TrimText : UserControl
    {
        public TrimText()
        {
            InitializeComponent();
        }
    }
}
