﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartifyBotStudio.RobotDesigner.Enums
{
    public enum RobotActionsEnum
    {
        CopyFile,
        DeleteFile,
        GetFilePathPart,
        GetFilesinFolder,
        MoveFiles,
        ReadFromCSVFile,
        ReadTextFromFile,
        RenameFiles,
        WriteTextToFile,
        WriteToCSVFile,
        GetTemporaryFile
    }
}
