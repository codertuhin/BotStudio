﻿using DevComponents.WPF.Controls;
using MaterialDesignThemes.Wpf;
using SmartifyBotStudio.RobotDesigner.Enums;
using SmartifyBotStudio.RobotDesigner.Interfaces;
using SmartifyBotStudio.RobotDesigner.TaskModel.File;
using SmartifyBotStudio.RobotDesigner.Variable;
using SmartifyBotStudio.TypeEditor;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SmartifyBotStudio.Models
{

    [Serializable]
    public class RobotActionBase
    {
        public static ObservableCollection<RobotActionBase> CreateFileTasks()
        {
            ObservableCollection<RobotActionBase> list = new ObservableCollection<RobotActionBase>()
            {

                 new CopyFiles(){ ActionType = RobotActionsEnum.CopyFile, Name = "Copy File",   ID = "CopyFile", Description = "File Copy Description", Finished = false, Icon = PackIconKind.ContentCopy, IsExisting = false },
                 new DeleteFiles(){ ActionType = RobotActionsEnum.DeleteFile, Name = "Delete Files",   ID = "DeleteFiles", Description = "File Delete Description", Finished = false, Icon = PackIconKind.Delete, IsExisting = false },
                 new GetFilePathPart(){ ActionType = RobotActionsEnum.GetFilePathPart, Name = "Get File Path Part",   ID = "GetFilePathPart", Description = "Get File Path Part Description", Finished = false, Icon = PackIconKind.FileTree, IsExisting = false },
                 new GetFilesinFolder(){ ActionType = RobotActionsEnum.GetFilesinFolder, Name = "Get Files in Folder",   ID = "GetFilesInFolder", Description = "Get Files in Folder Description", Finished = false, Icon = PackIconKind.FileXml, IsExisting = false },
                 new MoveFiles(){ ActionType = RobotActionsEnum.MoveFiles, Name = "Move Files",   ID = "MoveFiles", Description = "Move Files Description", Finished = false, Icon = PackIconKind.FolderMove, IsExisting = false },
                 new ReadFromCSVFile(){ ActionType = RobotActionsEnum.ReadFromCSVFile, Name = "Read From CSV File",   ID = "ReadFromCSVFile", Description = "Read From CSV File Description", Finished = false, Icon = PackIconKind.TooltipText, IsExisting = false },
                 new ReadTextFromFile(){ ActionType = RobotActionsEnum.ReadTextFromFile, Name = "Read Text From File",   ID = "ReadTextFromFile", Description = "Read Text From File Description", Finished = false, Icon = PackIconKind.FileDocument, IsExisting = false },
                 new RenameFiles(){ ActionType = RobotActionsEnum.RenameFiles, Name = "Rename Files",   ID = "RenameFiles", Description = "Rename Files Description", Finished = false, Icon = PackIconKind.RenameBox, IsExisting = false },
                 new WriteTextToFile(){ ActionType = RobotActionsEnum.WriteTextToFile, Name = "Write Text To File",   ID = "WriteTextToFile", Description = "Write Text To File Description", Finished = false, Icon = PackIconKind.Pencil, IsExisting = false },
                 new WriteToCSVFile(){ ActionType = RobotActionsEnum.WriteToCSVFile, Name = "Write To CSV File",   ID = "WriteToCSVFile", Description = "Write To CSV File Description", Finished = false, Icon = PackIconKind.FileDelimited, IsExisting = false },

                 new GetTemporaryFiles(){ActionType = RobotActionsEnum.GetTemporaryFile, Name = "Get Templorary Files", ID = "GetTemporaryFiles", Description = "Get Templorary Files", Finished = false, Icon = PackIconKind.FileMultiple, IsExisting = false}
            };


            return list;
        }


        string name;
        string description;
        bool finished;


        public RobotActionBase() { }

        public RobotActionBase(PackIconKind icon, string id, string name, string description, bool finished, bool isExisting)
        {
            this.Icon = icon;
            this.ID = id;
            this.name = name;
            this.description = description;
            this.finished = finished;
            this.IsExisting = isExisting;
        }

        [Browsable(false)]
        public bool Finished
        {
            get { return this.finished; }
            set { this.finished = value; }
        }

        [Browsable(false)]
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        //[EditorAttribute(typeof(System.Windows.Forms.Design.FileNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
        //[Editor(typeof(FileSelectorTypeEditor), typeof(UITypeEditor))]
        [Browsable(false)]
        public string Description
        {
            get { return this.description; }
            set { this.description = value; }
        }

        [ReadOnly(true)]
        [Browsable(false)]
        public PackIconKind Icon { get; set; }

        [ReadOnly(true)]
        public string ID { get; set; }
        [Browsable(false)]
        public bool IsExisting { get; set; }

        [Browsable(false)]
        public int Index { get; set; }
        /// <summary>
        /// 
        [Browsable(false)]
        public RobotActionsEnum ActionType { get; set; }                                  /// Create object for serialization

        //[Category("Boolean Editor")]
        
        [DisplayName("Is Active")]
        [Description("When inactive the action will not be executed.")]
        [BooleanEditorDescriptor(Type = BooleanEditorDescriptor.EditorType.DropDown, EnableInCellEditing = true, AutoComplete = AutoCompleteOptions.ReadOnly)]
        public bool IsActive { get; set; }


        [NonSerialized]
        public List<VariableBase> Variables = new List<VariableBase>();
        //public List<VariableBase> Variables
        //{
        //    get
        //    {
        //        return _Variables;
        //    }
        //    set
        //    {
        //        _Variables = value;
        //    }
        //}

        [NonSerialized]
        RobotDesignerProjectModel _RobotDesignerProjectModel;
        public RobotDesignerProjectModel RobotDesignerProject
        {
            get { return _RobotDesignerProjectModel; }
            set { _RobotDesignerProjectModel = value; }
        }
    }
}
