function initData() {
  jimData.variables["Change_MainContent_Win"] = "0";
  jimData.isInitialized = true;
}