(function(window, undefined) {

  var jimLinks = {
    "d7f53983-48e4-48cb-801b-d88a5f508daa" : {
    },
    "aa0e3abb-c388-4de2-8a06-8eb74103bee7" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);