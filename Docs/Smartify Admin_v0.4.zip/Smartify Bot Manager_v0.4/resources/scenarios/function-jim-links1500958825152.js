(function(window, undefined) {

  var jimLinks = {
    "d6ecc889-b86b-4a08-b470-459a73822b51" : {
    },
    "6f08728c-bfb0-4437-8ccf-51291d987c49" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);