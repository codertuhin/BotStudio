function initData() {
  jimData.variables["VChange_MainWin_Panel"] = "0";
  jimData.isInitialized = true;
}