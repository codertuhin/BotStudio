function initData() {
  jimData.variables["Loop"] = "0";
  jimData.variables["vRecord_task_start"] = "0";
  jimData.variables["Change_MainContent_win"] = "0";
  jimData.isInitialized = true;
}