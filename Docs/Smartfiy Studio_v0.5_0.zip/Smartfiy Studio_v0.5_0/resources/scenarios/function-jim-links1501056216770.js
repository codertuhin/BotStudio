(function(window, undefined) {

  var jimLinks = {
    "624f2e2e-99f4-4899-8305-b4630f3490a8" : {
      "Hotspot_1" : [
        "9e415898-0f31-49d7-b415-e7473fd5ce7c"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Capture_a_task" : [
        "18518461-5e6f-49f2-962c-8534d12afc9e"
      ],
      "Image_119" : [
        "9e415898-0f31-49d7-b415-e7473fd5ce7c"
      ]
    },
    "18518461-5e6f-49f2-962c-8534d12afc9e" : {
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "b8319b0d-dc4e-42a2-99bb-64aa3e7ec141" : {
    },
    "9e415898-0f31-49d7-b415-e7473fd5ce7c" : {
      "Hotspot_2" : [
        "18518461-5e6f-49f2-962c-8534d12afc9e"
      ],
      "Hotspot_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "8882a99c-f096-41cc-b4ae-529634b5b670" : {
      "Rich_text_233" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "4fefdcb0-9f17-49ca-9e90-138b3d98939c" : {
      "Capture_a_task" : [
        "18518461-5e6f-49f2-962c-8534d12afc9e"
      ]
    },
    "e836f5bd-d384-423d-90e4-64231329e583" : {
    },
    "2556543e-5d07-4778-ab9c-24282c35ccf5" : {
    },
    "0b63b289-d0d9-4cdb-9bbb-39f1f6ca1d1f" : {
    },
    "e28f6256-18c0-472a-a86d-2258cb558b7e" : {
    },
    "a0618400-2069-4c6b-b141-8d53a689d39e" : {
    },
    "2140e15f-d921-49ce-b858-cb2140356d6c" : {
    },
    "0c27f18e-cb20-4ee5-bea9-2d7f4134596d" : {
    },
    "2f824c66-492d-4049-bb27-5521387ec12b" : {
      "Hotspot_2" : [
        "18518461-5e6f-49f2-962c-8534d12afc9e"
      ],
      "Hotspot_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);